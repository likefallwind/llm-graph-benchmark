#!/usr/bin/env bash
# Keeps the RL rerun going: on a quota stop (MiniMax 2067/1008) wait 10 min and
# resume with --retry-failed; after the queue drains, retry technical failures
# up to 3 rounds with the same pause. Auth errors stop the watcher.
set -u
ROOT=/home/likefallwind/code/llm-graph-benchmark
RUN=$ROOT/outputs/rl-rerun-fontfix-20260926
CLI=$ROOT/.venv/bin/llm-graph-benchmark
LOG=$RUN/quota-watch.log
PAUSE=600
MAX_QUOTA_WAITS=144
MAX_FAILED_ROUNDS=0
cd "$ROOT"
eval "$(grep -m1 '^export MINIMAX_API_KEY=' ~/.bashrc)"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
field() { "$ROOT/.venv/bin/python" -c "import json,sys; s=json.load(sys.stdin); print($1)"; }

quota_waits=0
failed_rounds=0
log "watcher started"
while true; do
  st=$("$CLI" workflow status --run "$RUN" 2>/dev/null)
  active=$(echo "$st" | field 's["active"]')
  if [ "$active" = "True" ]; then sleep 60; continue; fi
  phase=$(echo "$st" | field 's["phase"]')
  pending=$(echo "$st" | field 's["statuses"].get("pending",0)')
  failed=$(echo "$st" | field 's["statuses"].get("failed",0)')
  terminal=$(echo "$st" | field 's["statuses"].get("terminal_provider_error",0)')
  done_n=$(echo "$st" | field 's["done"]')
  log "phase=$phase done=$done_n pending=$pending failed=$failed terminal=$terminal"

  if [ "$phase" = "provider_error" ] || [ "$terminal" != "0" ]; then
    err=$(cat "$RUN/api/terminal-error.json" 2>/dev/null)
    if echo "$err" | grep -Eq 'code (2067|1008)'; then
      quota_waits=$((quota_waits + 1))
      if [ "$quota_waits" -gt "$MAX_QUOTA_WAITS" ]; then log "quota still exhausted after 24h, stopping"; exit 4; fi
      log "quota exhausted ($err); pause ${PAUSE}s (#$quota_waits)"
      sleep "$PAUSE"
      "$CLI" workflow launch --run "$RUN" --retry-failed >> "$LOG" 2>&1
      sleep 30; continue
    fi
    log "non-quota terminal error, stopping: $err"; exit 4
  fi

  if [ "$pending" != "0" ]; then
    log "interrupted with pending tasks; relaunching"
    "$CLI" workflow launch --run "$RUN" >> "$LOG" 2>&1
    sleep 30; continue
  fi

  if [ "$failed" != "0" ] && [ "$failed_rounds" -lt "$MAX_FAILED_ROUNDS" ]; then
    failed_rounds=$((failed_rounds + 1))
    log "technical failures remain; pause ${PAUSE}s then retry (round $failed_rounds)"
    sleep "$PAUSE"
    "$CLI" workflow launch --run "$RUN" --retry-failed >> "$LOG" 2>&1
    sleep 30; continue
  fi

  "$CLI" workflow report --run "$RUN" >> "$LOG" 2>&1
  log "finished: phase=$phase done=$done_n failed=$failed"
  exit 0
done
