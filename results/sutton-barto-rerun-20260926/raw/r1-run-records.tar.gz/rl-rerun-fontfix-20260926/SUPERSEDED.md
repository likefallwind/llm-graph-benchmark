Interrupted 2026-09-26 22:07 to fix the relation-granularity parser (markdown ```json fences).
Its 1,392 completed results were copied unchanged into ../rl-rerun-fontfix-20260926-r2 (identical task IDs and hashes);
the run continues there. This directory is kept only as the audit trail of those requests.
